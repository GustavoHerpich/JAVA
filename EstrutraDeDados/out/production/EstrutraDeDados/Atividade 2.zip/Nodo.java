package AtividadeListas;

public class Nodo {
    public int elem;
    public Nodo ant, prox;

}
